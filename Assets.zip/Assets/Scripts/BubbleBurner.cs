using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubbleBurner : MonoBehaviour
{
    public GameObject BubblePrefab;
    public bool IsLoop;
    public int BurnCount;
    public float BurnInterval;
    public Transform BurnRoot;
    public float BurnRandom;
        

    public void GenerateBubble()
    {
        GameObject obj = GameObject.Instantiate(BubblePrefab);
        //obj.

    }

}
