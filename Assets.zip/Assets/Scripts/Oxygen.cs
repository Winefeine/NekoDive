using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class Oxygen : MonoBehaviour
{
    public Vector3 Offset;
    public float LowOxygen;
    public Image FillImage;
    public Transform owner;
    float offsetBuffer = 3f;

    void Start()
    {
        FillImage = transform.GetChild(0).GetComponent<Image>();
        owner = transform.parent.parent;
    }

    void Update()
    {
        UpdateOxygenBar();
    }


    public void UpdateOxygenBar()
    {
        float cur = 0f;
        float max = 0f;
        if(owner.GetComponent<PlayerController>())
        {
            PlayerController player = owner.GetComponent<PlayerController>();
            Offset = new Vector3(0f,2f,0f);
            cur = player.CurOxygen;
            max = player.OxygenTank;
        }else if(owner.GetComponent<BubbleController>())
        {
            BubbleController bubble = owner.GetComponent<BubbleController>();
            Offset = new Vector3(0f,bubble.CurScale * offsetBuffer,0f);
            cur = bubble.CurOxygen;
            max = bubble.OyxgenTank;
        }


        FillImage.fillAmount = cur/max; 
        Vector3 screenPos = Camera.main.WorldToScreenPoint(owner.position + Offset);

        // 更新血量条在 Canvas 中的位置
        transform.position = screenPos;
    }




}
