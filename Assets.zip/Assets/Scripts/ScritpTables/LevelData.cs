using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewLevelData", menuName = "Game Data/Level")]
public class LevelData : ScriptableObject
{
    public string LevelName;
    //public Dictionary<Vector3,Game
    
}

